#!/bin/bash

if [ $1 ]; then
    sed -rnf commands.sed $1
else
    echo No File Provided
    exit 1
fi
